-- Upgrade an existing Armstrong 2026 database to two distinct votes per code.
-- Run once in Supabase SQL Editor AFTER the original setup.sql.
-- Existing one-vote ballots remain counted; their already-used codes stay spent.

-- Allow two vote rows per code, but never twice for the same candidate.
alter table public.votes drop constraint if exists votes_code_hash_key;
create unique index if not exists votes_code_candidate_unique on public.votes(code_hash, candidate_id);

-- Disable the old one-vote RPC to prevent alternate voting routes.
revoke execute on function public.cast_class_vote(text,uuid) from anon, authenticated, public;

create or replace function public.cast_two_votes(ballot_code text, chosen_candidates uuid[])
returns jsonb
language plpgsql security definer set search_path = ''
as $$
declare hashed text;
begin
 if coalesce((select voting_closed from public.election_settings where id=1),true) then
  return jsonb_build_object('ok',false,'message','Voting is closed.');
 end if;
 if ballot_code is null or length(trim(ballot_code)) < 1 or length(trim(ballot_code)) > 32 then
  return jsonb_build_object('ok',false,'message','Invalid voting code.');
 end if;
 if chosen_candidates is null or array_length(chosen_candidates,1) <> 2
    or chosen_candidates[1] is null or chosen_candidates[2] is null
    or chosen_candidates[1] = chosen_candidates[2] then
  return jsonb_build_object('ok',false,'message','Choose two different names.');
 end if;
 if (select count(*) from public.candidates where id = any(chosen_candidates)) <> 2 then
  return jsonb_build_object('ok',false,'message','One or more names are invalid.');
 end if;
 hashed := encode(extensions.digest(upper(trim(ballot_code)),'sha256'),'hex');
 -- Atomic reservation ensures concurrent submissions cannot reuse the same code.
 update public.ballot_codes set used_at=now() where code_hash=hashed and used_at is null;
 if not found then
  return jsonb_build_object('ok',false,'message','Code not found or already used.');
 end if;
 insert into public.votes(candidate_id,code_hash)
 select unnest(chosen_candidates),hashed;
 return jsonb_build_object('ok',true);
end $$;
revoke all on function public.cast_two_votes(text,uuid[]) from public;
grant execute on function public.cast_two_votes(text,uuid[]) to anon,authenticated;

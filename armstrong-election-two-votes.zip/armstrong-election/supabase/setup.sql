-- Run once in Supabase SQL Editor. Requires pgcrypto (included on Supabase).
create extension if not exists pgcrypto;
create table if not exists public.candidates (
 id uuid primary key default gen_random_uuid(),
 name text not null unique check (char_length(name) between 1 and 70),
 slogan text not null default 'A name worth voting for.',
 description text not null default '',
 color text not null default '#d9b66d',
 created_at timestamptz not null default now()
);
create table if not exists public.campaign_ads (
 id uuid primary key default gen_random_uuid(),
 candidate_id uuid references public.candidates(id) on delete cascade,
 headline text not null check(char_length(headline) between 1 and 90),
 body text not null check(char_length(body) between 1 and 500),
 tagline text not null default 'Classroom campaign advertisement',
 created_at timestamptz not null default now()
);
create table if not exists public.admins (user_id uuid primary key references auth.users(id) on delete cascade);
create table if not exists public.election_settings (id integer primary key check(id=1), voting_closed boolean not null default false);
insert into public.election_settings(id,voting_closed) values(1,false) on conflict(id) do nothing;
create table if not exists public.ballot_codes (code_hash text primary key, used_at timestamptz);
create table if not exists public.votes (
 id bigint generated always as identity primary key,
 candidate_id uuid not null references public.candidates(id) on delete restrict,
 code_hash text not null unique references public.ballot_codes(code_hash),
 created_at timestamptz not null default now()
);
create or replace view public.public_results with (security_invoker=false) as
 select c.id as candidate_id, count(v.id)::integer as votes from public.candidates c left join public.votes v on v.candidate_id=c.id group by c.id;
-- Access control. Nobody can directly read individual ballots or code hashes.
alter table public.candidates enable row level security;
alter table public.campaign_ads enable row level security;
alter table public.admins enable row level security;
alter table public.election_settings enable row level security;
alter table public.ballot_codes enable row level security;
alter table public.votes enable row level security;
create policy "Anyone can view candidates" on public.candidates for select to anon,authenticated using(true);
create policy "Anyone can view ads" on public.campaign_ads for select to anon,authenticated using(true);
create policy "Anyone can view election status" on public.election_settings for select to anon,authenticated using(true);
create policy "Admins can view their own admin record" on public.admins for select to authenticated using(user_id=auth.uid());
create policy "Admins can add candidates" on public.candidates for insert to authenticated with check(exists(select 1 from public.admins where user_id=auth.uid()));
create policy "Admins can remove candidates" on public.candidates for delete to authenticated using(exists(select 1 from public.admins where user_id=auth.uid()));
create policy "Admins can add ads" on public.campaign_ads for insert to authenticated with check(exists(select 1 from public.admins where user_id=auth.uid()));
create policy "Admins can remove ads" on public.campaign_ads for delete to authenticated using(exists(select 1 from public.admins where user_id=auth.uid()));
create policy "Admins can close polls" on public.election_settings for update to authenticated using(exists(select 1 from public.admins where user_id=auth.uid())) with check(exists(select 1 from public.admins where user_id=auth.uid()));
revoke all on public.ballot_codes from anon,authenticated;
revoke all on public.votes from anon,authenticated;
revoke all on public.admins from anon;
grant select on public.public_results to anon,authenticated;
-- SECURITY DEFINER RPC validates a code and marks it used atomically.
create or replace function public.cast_class_vote(ballot_code text, chosen_candidate uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare hashed text;
begin
 if (select voting_closed from public.election_settings where id=1) then
  return jsonb_build_object('ok',false,'message','Voting is closed.');
 end if;
 if ballot_code is null or length(trim(ballot_code)) > 32 then
  return jsonb_build_object('ok',false,'message','Invalid voting code.');
 end if;
 if not exists(select 1 from public.candidates where id=chosen_candidate) then
  return jsonb_build_object('ok',false,'message','Invalid candidate.');
 end if;
 hashed:=encode(extensions.digest(upper(trim(ballot_code)),'sha256'),'hex');
 update public.ballot_codes set used_at=now() where code_hash=hashed and used_at is null;
 if not found then
  return jsonb_build_object('ok',false,'message','Code not found or already used.');
 end if;
 insert into public.votes(candidate_id,code_hash) values(chosen_candidate,hashed);
 return jsonb_build_object('ok',true);
end $$;
-- Only signed-in allowlisted admins may generate codes.
create or replace function public.generate_ballot_codes(how_many integer)
returns text[] language plpgsql security definer set search_path = '' as $$
declare codes text[]:='{}'; v text; i integer;
begin
 if auth.uid() is null or not exists(select 1 from public.admins where user_id=auth.uid()) then
  raise exception 'Not authorized';
 end if;
 if how_many is null or how_many < 1 or how_many > 100 then raise exception 'Generate between 1 and 100 codes'; end if;
 for i in 1..how_many loop
  v:=upper(encode(extensions.gen_random_bytes(6),'hex'));
  insert into public.ballot_codes(code_hash) values(encode(extensions.digest(v,'sha256'),'hex'));
  codes:=array_append(codes,v);
 end loop;
 return codes;
end $$;
revoke all on function public.cast_class_vote(text,uuid) from public;
grant execute on function public.cast_class_vote(text,uuid) to anon,authenticated;
revoke all on function public.generate_ballot_codes(integer) from public;
grant execute on function public.generate_ballot_codes(integer) to authenticated;
-- Seed only when there are no candidates. Fluffy and Peanut are examples, not confirmed nominees.
insert into public.candidates(name,slogan,description,color)
select v.name,v.slogan,v.description,v.color from (values
 ('Senator Steven Armstrong','A name. A vision. A guinea pig.','More hay. More tunnels. More dramatic speeches.','#d9b66d'),
 ('Fluffy','Small name. Big heart.','A timeless classic for a very fuzzy candidate.','#9ed3d0'),
 ('Peanut','A little name with a lot of charm.','A snack-sized name with enormous potential.','#d4a2bb')
) as v(name,slogan,description,color) where not exists(select 1 from public.candidates);
insert into public.campaign_ads(candidate_id,headline,body,tagline)
select id,'MAKE GUINEA PIGS GREAT AGAIN','UNLIMITED HAY. MORE HIDING TUNNELS. A STRONGER, SQUEAKIER CLASSROOM.','Paid for by the Committee for Extremely Dramatic Pet Names.' from public.candidates where name='Senator Steven Armstrong' and not exists(select 1 from public.campaign_ads);
insert into public.campaign_ads(candidate_id,headline,body,tagline)
select id,'KEEP IT CLASSIC','Fluffy: easy to remember, impossible to dislike.','A message from the Fluffy Naming Committee.' from public.candidates where name='Fluffy' and not exists(select 1 from public.campaign_ads where headline='KEEP IT CLASSIC');
insert into public.campaign_ads(candidate_id,headline,body,tagline)
select id,'THINK SMALL. DREAM BIG.','Peanut: a name as adorable as its future owner.','Paid for by Team Peanut.' from public.candidates where name='Peanut' and not exists(select 1 from public.campaign_ads where headline='THINK SMALL. DREAM BIG.');
-- Enable realtime for relevant public tables (votes only exposes change events; vote rows remain RLS-protected).
do $$ begin alter publication supabase_realtime add table public.candidates,public.campaign_ads,public.election_settings; exception when duplicate_object then null; end $$;


-- VIDEO AD UPLOADS (safe to run on existing installations too).
alter table public.campaign_ads add column if not exists video_path text;
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('campaign-videos','campaign-videos',true,52428800,array['video/mp4','video/webm'])
on conflict (id) do update set public=true,file_size_limit=52428800,allowed_mime_types=array['video/mp4','video/webm'];
-- Anyone can view public campaign videos; only election admins can upload or remove them.
create policy "Public can view campaign videos" on storage.objects for select to anon,authenticated
 using (bucket_id='campaign-videos');
create policy "Election admins can upload campaign videos" on storage.objects for insert to authenticated
 with check (bucket_id='campaign-videos' and exists(select 1 from public.admins where user_id=auth.uid()));
create policy "Election admins can remove campaign videos" on storage.objects for delete to authenticated
 using (bucket_id='campaign-videos' and exists(select 1 from public.admins where user_id=auth.uid()));
